package org.example.patriota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatriotaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PatriotaApplication.class, args);
    }

}
