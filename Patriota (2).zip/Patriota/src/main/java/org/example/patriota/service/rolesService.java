package org.example.patriota.service;

import org.example.patriota.entity.roles;
import org.example.patriota.repository.rolesRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class rolesService {
    private final rolesRepository repository;

    public rolesService(rolesRepository repository) {
        this.repository = repository;
    }

    public List<roles> listarRoles() {
        return repository.findAll();
    }
    
    public roles guardar(roles roles) {
        return repository.save(roles);
    }
}