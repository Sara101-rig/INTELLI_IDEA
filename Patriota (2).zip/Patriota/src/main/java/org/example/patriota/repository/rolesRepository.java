package org.example.patriota.repository;

import org.example.patriota.entity.roles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface rolesRepository extends JpaRepository<roles, Integer> {

}