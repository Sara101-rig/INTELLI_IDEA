package org.example.patriota.controller;

import org.example.patriota.entity.roles;
import org.example.patriota.service.rolesService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/roles")
public class rolesController {

    private final rolesService service; //

    public rolesController(rolesService service) {
        this.service = service;
    }

    @GetMapping
    public List<roles> listar() {
        return service.listarRoles();
    }


}