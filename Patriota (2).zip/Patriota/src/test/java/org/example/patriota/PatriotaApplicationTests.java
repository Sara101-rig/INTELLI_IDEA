package org.example.patriota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatriotaApplicationTests {

    @Test
    void contextLoads() {
    }

}
